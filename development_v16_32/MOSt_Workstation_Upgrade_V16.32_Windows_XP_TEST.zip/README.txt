MOSt V16.32 WINDOWS XP PATIENT-TO-LETTERBUILDER SWITCH TEST
Executable version: 1.7.633

This replaces the V16.31 XP test build and retains all earlier repairs.

Behavior:
- Patient-screen Letters opens LetterBuilder for the active patient under AB.
- Only one LetterBuilder instance is used on that XP workstation.
- If LetterBuilder is already showing another patient, the Patients-screen Letters
  button feeds the new patient ID into LetterBuilder's existing search.Valid()
  patient-number routine. This is the same internal switching sequence used when
  entering another patient number directly in LetterBuilder.
- The current letter therefore follows LetterBuilder's established completion/save
  behavior before LetterBuilder loads the newly selected patient.
- AB remains selected because legacy letters are stored under AB.
- LetterBuilder opens below Patients when possible, otherwise to the right.
- V16.29's separate cross-workstation Word owner-file check remains unchanged:
  another workstation encountering an actively locked letter gets View Read-Only
  or Cancel instead of entering the legacy freeze path.

Required XP test:
1. Open patient A on Patients and click Letters.
2. Confirm LetterBuilder shows patient A under AB.
3. Edit/finish the letter in the normal established manner.
4. Select patient B on Patients and click Letters.
5. Confirm the same LetterBuilder instance switches to patient B and the patient A
   letter was saved exactly as with direct patient-number switching in LetterBuilder.
6. Confirm no second LetterBuilder opens.
7. Separately repeat the two-workstation locked-letter read-only/cancel test.

This is a test build for copied data before production use. It contains no MOSt
clinical database files and must not be installed on Windows 10/11 or the server.