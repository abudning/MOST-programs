Option Explicit
Dim shell, fso, targetFolder, desktop, menuFolder, shortcut
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count = 0 Then WScript.Quit 2
targetFolder = WScript.Arguments(0)
desktop = shell.SpecialFolders("Desktop")
Set shortcut = shell.CreateShortcut(fso.BuildPath(desktop, "MOSt.lnk"))
shortcut.TargetPath = fso.BuildPath(targetFolder, "MOST.exe")
shortcut.Arguments = "-C" & Chr(34) & fso.BuildPath(targetFolder, "CONFIG.FPW") & Chr(34)
shortcut.WorkingDirectory = targetFolder
shortcut.Description = "MOSt V16.16 Workstation"
shortcut.Save
menuFolder = shell.SpecialFolders("Programs")
Set shortcut = shell.CreateShortcut(fso.BuildPath(menuFolder, "MOSt.lnk"))
shortcut.TargetPath = fso.BuildPath(targetFolder, "MOST.exe")
shortcut.Arguments = "-C" & Chr(34) & fso.BuildPath(targetFolder, "CONFIG.FPW") & Chr(34)
shortcut.WorkingDirectory = targetFolder
shortcut.Description = "MOSt V16.16 Workstation"
shortcut.Save
