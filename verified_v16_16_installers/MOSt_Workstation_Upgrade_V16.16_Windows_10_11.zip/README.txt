MOSt V16.16 WINDOWS 10/11 WORKSTATION TEST UPGRADE
Executable version: 1.7.613

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Close MOSt before running the installer. Use a local Administrator account for
the installation only. After installation, start MOSt normally from the newly
created shortcut; do not use Run as administrator.

This release makes Modify Labels use the detected local MOSt LABELS directory.
It includes the V16.15 Claims fee and Visual FoxPro resource corrections.
