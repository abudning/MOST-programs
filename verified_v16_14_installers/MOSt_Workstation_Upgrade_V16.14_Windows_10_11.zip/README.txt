MOSt V16.14 WORKSTATION UPGRADE
Executable version: 1.7.611

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Close MOSt before running the installer. Use a local Administrator account.
Complete the supplied Word guide and pre-live test checklist before production use.
