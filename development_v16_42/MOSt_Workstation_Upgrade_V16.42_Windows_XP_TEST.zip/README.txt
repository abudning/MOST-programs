MOSt V16.42 WINDOWS XP DIRECT LETTER LIST / RX SPACE IMPORT TEST
Executable version: 1.7.643

This replaces V16.34 and retains all earlier repairs.

- LetterBuilder remains fixed to AB.
- Loading a patient now runs the complete legacy ID control lifecycle twice:
  ID mode, patient number, focus, Valid, LostFocus, then the same sequence again.
  This deterministically reproduces the manual re-entry that displays the letter list.
- Before switching patients, MOSt captures LetterBuilder Left, Top and WindowState.
  After loading the new patient it restores those exact values.
- If LetterBuilder has ever been manually moved, it remains there for all later
  patient changes and repeated Letters clicks.
- On its first opening, LetterBuilder is aligned directly below Claims with no gap.
- The automatic position beside Patients/below Claims is applied only when a new
  LetterBuilder window is first created.
- Clicking Letters for the same patient raises the existing window without a notice.

TEST ON COPIED DATA:
1. Open a patient with known letters and confirm its letter list appears immediately.
2. Move LetterBuilder manually.
3. Change patient on Patients, click Letters, and confirm the new patient's list
   appears while LetterBuilder stays at the exact manually selected position.
4. Repeat across several patients and test the same-patient raise behavior.

No MOSt clinical database files are included.
- LetterBuilder directly calls the AB existing-letter list routine after patient validation.
- Glasses OD/OS import ignores spaces and tabs inside sphere/cylinder/axis text.

- LetterBuilder performs a full Update, builds the AB list, selects the first existing letter, and loads its detail panel and controls.
- Sphere-only OD/OS lines are accepted; cylinder and axis default to zero.

- Daily Summary Billing MD now lists only MD records with Payment % not equal to zero.
- ALL DOCTORS remains available when more than one active MD exists.

Billing-MD lists now exclude Payment %=0 in:
- Daily Summary and Check-In Report
- Outstanding Submitted Claims
- Referring MD Statistics
- Submitted Service Codes
- Fix RA Errors (billing MD only; referring MD list unchanged)
