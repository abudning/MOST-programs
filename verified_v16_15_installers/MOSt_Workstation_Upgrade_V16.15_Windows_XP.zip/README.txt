MOSt V16.15 WINDOWS XP WORKSTATION TEST UPGRADE
Executable version: 1.7.612

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Extract the complete ZIP, close MOSt, and run the CMD installer using a local
Administrator account. Do not use a self-extracting installer on Windows XP.

This release directs Claims to the configured shared fee table. Test A233A
before production use.
