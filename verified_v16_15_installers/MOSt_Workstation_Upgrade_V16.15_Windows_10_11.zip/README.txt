MOSt V16.15 WINDOWS 10/11 WORKSTATION TEST UPGRADE
Executable version: 1.7.612

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Close MOSt before running the installer. Use a local Administrator account for
the installation only. After installation, start MOSt normally from the newly
created shortcut; do not use Run as administrator.

This release directs Claims to the configured shared fee table and disables the
unnecessary Visual FoxPro resource file. Test A233A before production use.
