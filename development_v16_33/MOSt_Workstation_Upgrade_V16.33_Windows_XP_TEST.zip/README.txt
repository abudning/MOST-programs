MOSt V16.33 WINDOWS XP THREE-WINDOW WORKFLOW TEST
Executable version: 1.7.634

This replaces V16.32 and retains all prescription and letter-lock repairs.

LetterBuilder corrections:
- Defaults to AB from both Patients > Letter Builder and the patient-screen button.
- Patient-screen launching selects AB, enters ID mode, copies the patient number
  into LetterBuilder's search/ID box, focuses it, and sends Enter.
- Changing patients on the Patients screen and pressing Letters repeats that same
  ID-plus-Enter sequence in the existing LetterBuilder.
- Pressing Letters for the patient already displayed silently raises the existing
  LetterBuilder; it no longer displays an already-open notice.

Window layout:
- The patient-screen Claims button opens/reuses the matching Claims window to the
  right of Patients.
- New Patients-menu command: Patient / Claims / Letters.
- That command opens/reuses Patients at top-left, Claims to its right, and
  LetterBuilder below Claims and to the right of Patients.
- Existing matching windows are reused instead of duplicated.
- Positions are clamped to remain within the visible MOSt desktop.

Cross-workstation behavior is separate and unchanged: an actively locked Word
letter offers View Read-Only or Cancel rather than entering the legacy freeze path.

TEST ON COPIED DATA BEFORE PRODUCTION. Verify the layout at the actual XP screen
resolution and confirm that switching patient A to patient B completes/saves A and
loads B exactly as entering a new ID and pressing Enter inside LetterBuilder.
This installer contains no MOSt clinical database files.