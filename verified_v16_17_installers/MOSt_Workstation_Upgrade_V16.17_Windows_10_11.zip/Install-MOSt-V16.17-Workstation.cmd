@echo off
setlocal EnableExtensions
title MOSt V16.17 Workstation Upgrade
echo.
echo MOSt V16.17 - Windows 10/11 WORKSTATION upgrade
echo This installer must NOT be run on Windows Server 2008.
echo It does not copy or alter MOSt database files.
echo.

net session >nul 2>&1
if errorlevel 1 (
  echo Requesting local Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$o=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue; if(-not $o){$o=Get-WmiObject Win32_OperatingSystem}; if([int]$o.ProductType -ne 1){exit 42}"
if errorlevel 42 goto :server

tasklist /FI "IMAGENAME eq MOST.exe" 2>nul | find /I "MOST.exe" >nul
if not errorlevel 1 goto :running

if defined ProgramFiles(x86) (set "TARGET=%ProgramFiles(x86)%\MOSt") else (set "TARGET=%ProgramFiles%\MOSt")
if not exist "%TARGET%\MOST.exe" goto :missing

echo Installing to "%TARGET%"...
if not exist "%TARGET%\MOST_before_V16_17.exe" copy /Y "%TARGET%\MOST.exe" "%TARGET%\MOST_before_V16_17.exe" >nul || goto :failed

for %%F in (MOST.exe CONFIG.FPW MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll) do copy /Y "%~dp0%%F" "%TARGET%\%%F" >nul || goto :failed

set "REGSVR=%SystemRoot%\SysWOW64\regsvr32.exe"
if not exist "%REGSVR%" set "REGSVR=%SystemRoot%\System32\regsvr32.exe"
for %%F in (GbXMLParse.dll GbSubclass.ocx GbSchedule.ocx) do "%REGSVR%" /s "%TARGET%\%%F" || goto :register

if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
if not exist "%LOCALAPPDATA%\MOSt" mkdir "%LOCALAPPDATA%\MOSt" || goto :failed
>"%LOCALAPPDATA%\MOSt\installation_role.txt" echo WORKSTATION
>"%TARGET%\MOSt_Workstation_Version.txt" echo MOSt V16.17 - executable version 1.7.614 - WORKSTATION
cscript.exe //nologo "%~dp0CreateShortcut.vbs" "%TARGET%"

echo.
echo SUCCESS: MOSt V16.17 was installed on this WORKSTATION only.
echo Server programs and databases were not copied or changed.
echo Previous executable: "%TARGET%\MOST_before_V16_17.exe"
echo Complete the pre-live checklist before production use.
pause
exit /b 0

:server
echo ERROR: A server-class Windows installation was detected.
echo This package is intentionally blocked on servers. Windows Server 2008 remains unchanged.
pause
exit /b 42
:running
echo ERROR: MOST.exe is running. Close MOSt and try again.
pause
exit /b 3
:missing
echo ERROR: Existing MOSt workstation installation was not found in "%TARGET%".
echo This is an upgrade-only package; it will not create a new installation or database.
pause
exit /b 4
:register
echo ERROR: A scheduler component could not be registered. No database files were changed.
pause
exit /b 5
:failed
echo ERROR: The local workstation upgrade did not complete. No database files were changed.
pause
exit /b 6
