MOSt V16.17 WINDOWS 10/11 WORKSTATION PRESCRIPTION TEST UPGRADE
Executable version: 1.7.614

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Close MOSt before running the installer. Use a local Administrator account for
the installation only. After installation, start MOSt normally from the newly
created shortcut; do not use Run as administrator.

This release adds New Rx for medication or glasses prescriptions and adds
Prescription History to the patient EMR menu. Both prescription types are
read from shared structured database records, so past prescriptions can be
viewed without Word. Glasses prescriptions can be entered manually on Windows
10/11. Word import is optional and should be used only where compatible Word
automation is available.

The first use creates RXOPTICAL.DBF/FPT/CDX in the configured shared database
folder. Test only with a complete copied database first. Back up the full
server MOSt folder before any live pilot. This package never includes or
overwrites clinical database files.

Includes the V16.16 Modify Labels path correction, Claims fee correction and
Visual FoxPro resource correction.
