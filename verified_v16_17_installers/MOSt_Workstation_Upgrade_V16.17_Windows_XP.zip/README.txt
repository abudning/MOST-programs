MOSt V16.17 WINDOWS XP WORKSTATION PRESCRIPTION TEST UPGRADE
Executable version: 1.7.614

This is an upgrade-only package for an existing workstation.
DO NOT RUN IT ON WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX, or FPT data files.
The existing server application and shared data are intentionally unchanged.

Extract the complete ZIP, close MOSt, and run the CMD installer using a local
Administrator account. Do not use a self-extracting installer on Windows XP.

This release adds New Rx for medication or glasses prescriptions and adds
Prescription History to the patient EMR menu. Glasses prescriptions are kept
as structured shared DBF records and can be viewed without Word. On XP, the
glasses form can import a highlighted complete OD/OS refraction from an open
Word chart; the values must be confirmed before they are copied or issued.

The first use creates RXOPTICAL.DBF/FPT/CDX in the configured shared database
folder. Test only with a complete copied database first. Back up the full
server MOSt folder before any live pilot. This package never includes or
overwrites clinical database files.
