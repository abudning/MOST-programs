MOSt V16.30 WINDOWS XP SINGLE LETTERBUILDER TEST
Executable version: 1.7.631

This build carries forward the working V16.28 prescription repairs and the
V16.29 multi-workstation Word letter lock handling unchanged.

V16.30 changes Windows XP LetterBuilder launching:

- Only one LetterBuilder window can be open on an XP workstation.
- The patient-screen Letters button opens LetterBuilder for the current patient.
- It does not open an existing letter or start a new letter automatically.
- Patients > Letter Builder uses the same single-instance launcher.
- A second launch brings the existing LetterBuilder forward and reports that it
  is already open.
- If it is already open for another patient, MOSt asks the user to close it before
  opening LetterBuilder for the current patient. It does not silently change patients.
- Word opens only after the user explicitly chooses a Word/Edit/Print action.

TEST STATUS

The code compiles successfully and executable metadata is verified as 1.7.631.
This is an XP test build and must be tested on copied data before production use.

Required test:

1. Open patient A and press Letters. Confirm LetterBuilder shows patient A and no
   Word document opens.
2. Press Letters again. Confirm the same LetterBuilder comes forward, a notice says
   it is already open, and no second instance appears.
3. While it remains open, choose Patients > Letter Builder. Confirm the same result.
4. Close LetterBuilder, then choose Patients > Letter Builder. Confirm one general
   LetterBuilder opens and no letter or Word document starts.
5. Open LetterBuilder for patient A, navigate the patient screen to patient B, and
   press Letters. Confirm MOSt brings forward the existing window and asks that it
   be closed before opening patient B; patient A must not be silently replaced.
6. Re-test V16.28 medication/glasses prescriptions and V16.29 letter lock handling.

This is an upgrade-only package for an existing Windows XP workstation.
DO NOT RUN IT ON WINDOWS 10/11 OR WINDOWS SERVER 2008.
It contains no MOSt DBF, DBC, DCT, DCX, CDX or FPT data files.
It does not copy or alter the server program or clinical databases.

Extract the complete ZIP, close MOSt and Word, and run the CMD installer using
a local Administrator account. Back up the full server MOSt folder before any
live pilot.