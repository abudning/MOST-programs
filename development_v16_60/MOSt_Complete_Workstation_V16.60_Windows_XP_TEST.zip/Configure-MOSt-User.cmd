@echo off
setlocal EnableExtensions
set "TARGET=%ProgramFiles%\MOSt"
if not exist "%TARGET%\MOST.exe" goto missing
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\Local Settings\Application Data"
if not exist "%LOCALAPPDATA%\MOSt" mkdir "%LOCALAPPDATA%\MOSt"
>"%LOCALAPPDATA%\MOSt\installation_role.txt" echo WORKSTATION
cscript //nologo "%~dp0CreateShortcut.vbs" "%TARGET%"
pause
exit /b %ERRORLEVEL%
:missing
echo Install MOSt first.
pause
exit /b 4
