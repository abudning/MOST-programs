Option Explicit
Dim shell, fso, targetFolder, desktop, menuFolder, shortcut
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count = 0 Then WScript.Quit 2
targetFolder = WScript.Arguments(0)
desktop = shell.SpecialFolders("Desktop")
Set shortcut = shell.CreateShortcut(fso.BuildPath(desktop, "MOSt.lnk"))
shortcut.TargetPath = fso.BuildPath(targetFolder, "MOST.exe")
shortcut.Arguments = "-C" & Chr(34) & fso.BuildPath(targetFolder, "CONFIG.FPW") & Chr(34)
shortcut.WorkingDirectory = targetFolder
shortcut.Description = "MOSt V16.60 XP Workstation"
shortcut.Save
menuFolder = shell.SpecialFolders("Programs")
Set shortcut = shell.CreateShortcut(fso.BuildPath(menuFolder, "MOSt.lnk"))
shortcut.TargetPath = fso.BuildPath(targetFolder, "MOST.exe")
shortcut.Arguments = "-C" & Chr(34) & fso.BuildPath(targetFolder, "CONFIG.FPW") & Chr(34)
shortcut.WorkingDirectory = targetFolder
shortcut.Description = "MOSt V16.60 XP Workstation"
shortcut.Save

Dim startup, template
startup = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Word\STARTUP"
EnsureFolder startup
For Each template In Array("MOSt.dot", "MOSt_Special.dot")
 If Not fso.FileExists(startup & "\" & template) Then fso.CopyFile targetFolder & "\Word Templates\" & template, startup & "\" & template, False
Next
Sub EnsureFolder(path)
 If fso.FolderExists(path) Then Exit Sub
 If Not fso.FolderExists(fso.GetParentFolderName(path)) Then EnsureFolder fso.GetParentFolderName(path)
 fso.CreateFolder path
End Sub
