@echo off
setlocal EnableExtensions DisableDelayedExpansion
title MOSt V16.60 Windows XP Workstation Upgrade
echo.
echo MOSt V16.60 - Windows XP WORKSTATION prescription repair
echo This installer must NOT be run on Windows Server 2008.
echo Upgrade preserves local databases. New setup supplies local defaults only.
echo.

ver | find "5.1" >nul
if errorlevel 1 goto :wrongos
wmic os get ProductType /value 2>nul | find "=1" >nul
if errorlevel 1 goto :server
net session >nul 2>&1
if errorlevel 1 goto :admin
tasklist /FI "IMAGENAME eq MOST.exe" 2>nul | find /I "MOST.exe" >nul
if not errorlevel 1 goto :running

for %%F in (MOST.exe CONFIG.FPW MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll CreateShortcut.vbs Install-Resources.vbs) do if not exist "%~dp0%%F" goto :payloadmissing
set "TARGET=%ProgramFiles%\MOSt"
if /I "%~1"=="/new" goto :newsetup
if not exist "%TARGET%\MOST.exe" goto :missing
if not exist "%TARGET%\databases\oms_local.dbc" goto :missing
if not exist "%TARGET%\databases\parameter2.dbf" goto :missing
goto :install
:newsetup
for %%F in (oms_local.dbc oms_local.DCT oms_local.DCX parameter2.DBF options.dbf options.CDX daily.dbf daily.CDX MACROS.DBF MACROS.FPT) do if not exist "%~dp0NewWorkstationDefaults\%%F" goto :payloadmissing
if exist "%TARGET%" goto :existing
mkdir "%TARGET%\databases" || goto :failed
for %%F in (oms_local.dbc oms_local.DCT oms_local.DCX parameter2.DBF options.dbf options.CDX daily.dbf daily.CDX MACROS.DBF MACROS.FPT) do copy /B /Y "%~dp0NewWorkstationDefaults\%%F" "%TARGET%\databases\%%F" >nul || goto :failed
:install
echo Installing to "%TARGET%"...
set "BACKUP=%TARGET%\Setup_Backup_V16_60_%RANDOM%_%RANDOM%"
if exist "%BACKUP%" goto :failed
mkdir "%BACKUP%" || goto :failed
echo Backup: "%BACKUP%"
for %%F in (MOST.exe MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll) do (
 if exist "%TARGET%\%%F" (
  copy /B /Y "%TARGET%\%%F" "%BACKUP%\%%F" >nul
  if errorlevel 1 goto :failed
  fc /B "%TARGET%\%%F" "%BACKUP%\%%F" >nul
  if errorlevel 1 goto :failed
 )
)
for %%F in (MOST.exe MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll) do copy /Y "%~dp0%%F" "%TARGET%\%%F" >nul || goto :failed
if not exist "%TARGET%\CONFIG.FPW" copy /B /Y "%~dp0CONFIG.FPW" "%TARGET%\CONFIG.FPW" >nul || goto :failed
for %%F in (MOST.exe MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll) do fc /B "%~dp0%%F" "%TARGET%\%%F" >nul || goto :failed
cscript //nologo "%~dp0Install-Resources.vbs" "%TARGET%"
if errorlevel 1 goto :failed
for %%F in (GbXMLParse.dll GbSubclass.ocx GbSchedule.ocx) do "%SystemRoot%\System32\regsvr32.exe" /s "%TARGET%\%%F" || goto :register
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\Local Settings\Application Data"
if not exist "%LOCALAPPDATA%\MOSt" mkdir "%LOCALAPPDATA%\MOSt" || goto :failed
>"%LOCALAPPDATA%\MOSt\installation_role.txt" echo WORKSTATION
>"%TARGET%\MOSt_Workstation_Version.txt" echo MOSt V16.60 - executable version 1.7.661 - WORKSTATION - XP LetterBuilder lock handling and V16.28 prescriptions
cscript.exe //nologo "%~dp0CreateShortcut.vbs" "%TARGET%"
if errorlevel 1 goto :failed
echo.
echo SUCCESS: MOSt V16.60 was installed on this Windows XP WORKSTATION only.
echo Server programs and databases were not copied or changed.
echo Application backup: "%BACKUP%"
echo Complete the pre-live checklist before production use.
pause
exit /b 0
:wrongos
echo ERROR: This package is only for Windows XP workstations.
pause
exit /b 2
:server
echo ERROR: A server-class Windows installation was detected. Server 2008 remains unchanged.
pause
exit /b 42
:admin
echo ERROR: Sign in as a local Administrator, then run this installer again.
pause
exit /b 7
:running
echo ERROR: MOST.exe is running. Close MOSt and try again.
pause
exit /b 3
:missing
echo ERROR: Existing MOSt workstation installation was not found in "%TARGET%".
echo This is an upgrade-only package; it will not create a new installation or database.
pause
exit /b 4
:register
echo ERROR: A scheduler component could not be registered. No database files were changed.
pause
exit /b 5
:failed
echo ERROR: Setup incomplete. Do not start MOSt until corrected.
echo Application backup: "%BACKUP%". See README.txt for rollback.
pause
exit /b 6











:existing
echo ERROR: MOSt folder already exists. Use the upgrade installer.
pause
exit /b 4


:payloadmissing
echo ERROR: Extract ALL package files before running setup.
pause
exit /b 6

