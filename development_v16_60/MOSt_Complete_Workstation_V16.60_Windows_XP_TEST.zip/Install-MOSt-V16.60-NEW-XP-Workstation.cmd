@echo off
call "%~dp0Install-MOSt-V16.60-XP-Workstation.cmd" /new
exit /b %ERRORLEVEL%
