Option Explicit
Dim fso, sh, target, source, folder, rc
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
If WScript.Arguments.Count <> 1 Then WScript.Quit 2
target = WScript.Arguments(0)
source = fso.GetParentFolderName(WScript.ScriptFullName)
CopyMissingTree source & "\Labels", target & "\Labels"
CopyMissingTree source & "\Word Templates", target & "\Word Templates"
For Each folder In Array("Backup", "Backup\EDT", "Data", "EDT", "EDT\IN", "EDT\OUT", "Faxes", "Letters", "Letters\Save", "Letters\Deleted", "Temp")
 EnsureFolder target & "\" & folder
Next
' Give the installing user Modify access to local working folders.
For Each folder In Array("databases", "Backup", "Data", "EDT", "Faxes", "Labels", "Letters", "Temp")
 rc = sh.Run("cmd /c cacls " & Q(target & "\" & folder) & " /E /T /G " & Q(sh.ExpandEnvironmentStrings("%USERDOMAIN%\%USERNAME%") & ":C"), 0, True)
 If rc <> 0 Then Fail "Could not set local folder access: " & folder
Next
WScript.Quit 0
Sub EnsureFolder(path)
 If fso.FolderExists(path) Then Exit Sub
 If Not fso.FolderExists(fso.GetParentFolderName(path)) Then EnsureFolder fso.GetParentFolderName(path)
 On Error Resume Next
 fso.CreateFolder path
 If Err.Number <> 0 Then Fail "Could not create " & path & ": " & Err.Description
 On Error GoTo 0
End Sub
Sub CopyMissingTree(src, dst)
 Dim file, subfolder
 EnsureFolder dst
 For Each file In fso.GetFolder(src).Files
  If Not fso.FileExists(dst & "\" & file.Name) Then
   On Error Resume Next
   fso.CopyFile file.Path, dst & "\" & file.Name, False
   If Err.Number <> 0 Then Fail "Could not copy " & file.Name
   On Error GoTo 0
  End If
 Next
 For Each subfolder In fso.GetFolder(src).SubFolders
  CopyMissingTree subfolder.Path, dst & "\" & subfolder.Name
 Next
End Sub
Function Q(value)
 Q = Chr(34) & value & Chr(34)
End Function
Sub Fail(message)
 WScript.Echo "ERROR: " & message
 WScript.Quit 6
End Sub
