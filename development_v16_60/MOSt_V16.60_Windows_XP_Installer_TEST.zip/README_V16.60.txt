MOSt V16.60 Windows XP Claims Billing MD Persistence
Executable file version: 1.7.661
Built: September 14, 2026

Fixes after V16.59 testing
- The combined Letters and Claims button now displays the readable abbreviation "L +C".
- LetterWriter includes the XP title bar and border allowance when positioning below Claims, preventing overlap.
- Exit uses the standard XP button style so its face and red caption are visible; its blank clickable area is eliminated.
- Letters + Claims has an explicit two-line label.
- Letters + Claims directly opens or reuses Claims first, then opens or reuses LetterWriter for the current patient.
- Individual Claims and Letters buttons remain unchanged and clickable.
- LetterWriter initial positioning remains directly below Claims; manually moved LetterWriter windows retain their position.

- Scheduler now explicitly opens schedata from the configured shared path_to_data folder before querying rooms.
- The Scheduler database is opened SHARED for normal multi-workstation use.

- When an existing Claims window is reused for another patient, its current billing MD is retained.
- This applies when using Claims or L +C from the Patients screen.
- A blank billing MD remains blank when none was previously selected.

Multi-user behaviour
- SET EXCLUSIVE OFF remains unchanged.
- No new Patients SCX control record is added.
- Other workstations do not need to leave MOSt to open Patients.

Test checklist
1. Open Patients while another workstation is using MOSt.
2. Confirm First Pt and Exit are visible.
3. Confirm Exit closes Patients.
4. Confirm Claims and Letters both work individually.
5. Select a patient and test Letters + Claims.
6. Confirm LetterWriter opens immediately below Claims.
7. Move LetterWriter manually, change patient, and confirm its manually selected position remains.

No database files are included.