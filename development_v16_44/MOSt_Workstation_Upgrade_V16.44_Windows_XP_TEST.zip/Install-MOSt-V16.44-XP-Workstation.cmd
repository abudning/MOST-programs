@echo off
setlocal EnableExtensions
title MOSt V16.44 Windows XP Workstation Upgrade
echo.
echo MOSt V16.44 - Windows XP WORKSTATION prescription repair
echo This installer must NOT be run on Windows Server 2008.
echo It does not copy or alter MOSt database files.
echo.

ver | find "5.1" >nul
if errorlevel 1 goto :wrongos
wmic os get ProductType /value 2>nul | find "=1" >nul
if errorlevel 1 goto :server
net session >nul 2>&1
if errorlevel 1 goto :admin
tasklist /FI "IMAGENAME eq MOST.exe" 2>nul | find /I "MOST.exe" >nul
if not errorlevel 1 goto :running

set "TARGET=%ProgramFiles%\MOSt"
if not exist "%TARGET%\MOST.exe" goto :missing
echo Installing to "%TARGET%"...
if not exist "%TARGET%\MOST_before_V16_29.exe" copy /Y "%TARGET%\MOST.exe" "%TARGET%\MOST_before_V16_29.exe" >nul || goto :failed
for %%F in (MOST.exe CONFIG.FPW MOSt.chm GbSchedule.ocx GbSubclass.ocx GbXMLParse.dll CFHDR.H CVF50.FLL MCW32.DLL vfp9r.dll VFP9RENU.DLL msvcr71.dll) do copy /Y "%~dp0%%F" "%TARGET%\%%F" >nul || goto :failed
for %%F in (GbXMLParse.dll GbSubclass.ocx GbSchedule.ocx) do "%SystemRoot%\System32\regsvr32.exe" /s "%TARGET%\%%F" || goto :register
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\Local Settings\Application Data"
if not exist "%LOCALAPPDATA%\MOSt" mkdir "%LOCALAPPDATA%\MOSt" || goto :failed
>"%LOCALAPPDATA%\MOSt\installation_role.txt" echo WORKSTATION
>"%TARGET%\MOSt_Workstation_Version.txt" echo MOSt V16.44 - executable version 1.7.645 - WORKSTATION - XP LetterBuilder lock handling and V16.28 prescriptions
cscript.exe //nologo "%~dp0CreateShortcut.vbs" "%TARGET%"
echo.
echo SUCCESS: MOSt V16.44 was installed on this Windows XP WORKSTATION only.
echo Server programs and databases were not copied or changed.
echo Previous executable: "%TARGET%\MOST_before_V16_29.exe"
echo Complete the pre-live checklist before production use.
pause
exit /b 0
:wrongos
echo ERROR: This package is only for Windows XP workstations.
pause
exit /b 2
:server
echo ERROR: A server-class Windows installation was detected. Server 2008 remains unchanged.
pause
exit /b 42
:admin
echo ERROR: Sign in as a local Administrator, then run this installer again.
pause
exit /b 7
:running
echo ERROR: MOST.exe is running. Close MOSt and try again.
pause
exit /b 3
:missing
echo ERROR: Existing MOSt workstation installation was not found in "%TARGET%".
echo This is an upgrade-only package; it will not create a new installation or database.
pause
exit /b 4
:register
echo ERROR: A scheduler component could not be registered. No database files were changed.
pause
exit /b 5
:failed
echo ERROR: The local workstation upgrade did not complete. No database files were changed.
pause
exit /b 6







