MOSt V16.31 WINDOWS XP LETTERBUILDER AB TEST
Executable version: 1.7.632

This replaces the V16.30 XP test build.

Fixes and behavior:

- Removes the invalid form-level SetFocus calls that caused:
  "Property SETFOCUS is not found" in openletterwriter.fxp.
- Only one LetterBuilder can open per XP workstation.
- Patient-screen Letters opens LetterBuilder for the active patient.
- LetterBuilder is always set to MD mnemonic AB because legacy letters are filed
  under AB; no doctor selection screen and no All Doctors selection are used.
- It does not automatically open an existing letter or create a new letter.
- LetterBuilder opens below the Patients screen when space permits; otherwise it
  opens to the right. If necessary, it is kept within the visible MOSt desktop.
- Patients > Letter Builder uses the same single-instance launcher.
- A second launch restores the existing LetterBuilder and reports that it is open.
- V16.28 prescription repairs and V16.29 Word lock handling remain included.

Required XP test:

1. Open a patient and press Letters.
2. Confirm LetterBuilder shows that patient and AB is selected.
3. Confirm the patient's existing letter list is populated.
4. Confirm LetterBuilder is below Patients, or to its right when there is not enough
   space below.
5. Press Letters again and confirm no second LetterBuilder opens.
6. Close it and test Patients > Letter Builder; confirm no SetFocus error occurs.
7. Confirm Word does not start until an explicit letter/edit/print action is chosen.

This is an XP test build. Test with copied data before production use.
DO NOT RUN IT ON WINDOWS 10/11 OR WINDOWS SERVER 2008.
The package contains no MOSt DBF, DBC, DCT, DCX, CDX or FPT data files.