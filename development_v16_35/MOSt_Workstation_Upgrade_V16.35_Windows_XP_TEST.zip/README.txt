MOSt V16.35 WINDOWS XP LETTER RELOAD/POSITION TEST
Executable version: 1.7.636

This replaces V16.34 and retains all earlier repairs.

- LetterBuilder remains fixed to AB.
- Loading a patient now runs the complete legacy ID control lifecycle twice:
  ID mode, patient number, focus, Valid, LostFocus, then the same sequence again.
  This deterministically reproduces the manual re-entry that displays the letter list.
- Before switching patients, MOSt captures LetterBuilder Left, Top and WindowState.
  After loading the new patient it restores those exact values.
- If LetterBuilder has ever been manually moved, it remains there for all later
  patient changes and repeated Letters clicks.
- The automatic position beside Patients/below Claims is applied only when a new
  LetterBuilder window is first created.
- Clicking Letters for the same patient raises the existing window without a notice.

TEST ON COPIED DATA:
1. Open a patient with known letters and confirm its letter list appears immediately.
2. Move LetterBuilder manually.
3. Change patient on Patients, click Letters, and confirm the new patient's list
   appears while LetterBuilder stays at the exact manually selected position.
4. Repeat across several patients and test the same-patient raise behavior.

No MOSt clinical database files are included.