MOSt V16.34 WINDOWS XP LETTER LIST AND WINDOW POSITION TEST
Executable version: 1.7.635

This replaces V16.33 and retains all earlier prescription and Word-lock repairs.

Changes:
- LetterBuilder remains fixed to AB.
- Patient loading performs the complete ID-box focus and Enter sequence.
- If the first injected Enter leaves the letter list empty, MOSt repeats the same
  ID-and-Enter pass that succeeds when performed manually.
- Clicking Letters for the patient already displayed silently raises LetterBuilder.
- Existing LetterBuilder, Claims and Patients windows are never repositioned during
  later patient changes or repeated launches.
- Automatic layout occurs only when each window is first created. Manual moves made
  afterward are preserved.
- Claims initially opens to the right of Patients.
- The combined Patient / Claims / Letters command retains its initial three-window
  layout. At 1024x768, slight Claims/LetterBuilder overlap is unavoidable because
  LetterBuilder is 789x429; the initial position keeps the full form visible.

Required test:
1. Use Patient / Claims / Letters and confirm AB, patient name and current letter list.
2. If the patient has letters, confirm the list appears without manually re-entering ID.
3. Manually move all three windows.
4. Change patient on Patients and click Letters.
5. Confirm the same LetterBuilder loads the new patient's letter list and every
   manually adjusted window remains where it was.
6. Click Letters again for the same patient and confirm it raises LetterBuilder with
   no already-open message.

TEST ON COPIED DATA BEFORE PRODUCTION. No clinical database files are included.